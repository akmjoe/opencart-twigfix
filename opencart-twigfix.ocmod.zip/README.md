# Twig OCMOD fix

In opencart version 3.0.3.5 and 3.0.3.6 twig templates modified with ocmod are not loaded.
This extension fixes that.

### Installing

In your Opencart admin, go to Extensions > Installer and upload the extension.
Go to Extensions > Modifications and refresh your modifications.

## Authors

* **Joe Rothrock** - *Initial work* - [akmjoe](https://github.com/akmjoe)

## License

This project is licensed under the GPL License - see the [LICENSE.md](LICENSE.md) file for details



